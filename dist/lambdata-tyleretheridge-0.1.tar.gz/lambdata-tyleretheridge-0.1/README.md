# lambdata-tyleretheridge

## Installation

Fork this repo, then download your own copy of it. Then navigate into this directory from the command line. 

Then activate the virtual environment:


```sh
pipenv install
```
## Usage

TODO